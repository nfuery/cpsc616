Linux shell
Noah Fuery
CPSC616 - Professor Rene German
9/18/2023

Description:
This program emulates the function of a linux terminal, taking in string input and then outputting the corresponding command based on the input. It uses a fork() method which creates a child process, in the child process the command entered by the user is exectued and then is displayed. The program accounts for a simple level of error handling.

Sources:
stackoverflow.com
geeksforgeeks.com
github.com